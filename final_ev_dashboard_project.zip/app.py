import streamlit as st
import pandas as pd
import plotly.express as px

# Load data
market_df = pd.read_csv("ev_market_overview_2024.csv")
penetration_df = pd.read_csv("ev_penetration_fy2023_24.csv")
oem_df = pd.read_csv("top_ev_oems_2024.csv")

st.set_page_config(page_title="Indian EV Market Dashboard", layout="wide")

st.title("🔋 Indian EV Market Dashboard (2001–2024)")

st.header("📈 EV Sales Over the Years")
fig1 = px.line(market_df, x="Year", y="EV Sales", title="EV Sales in India (2001–2024)", markers=True)
st.plotly_chart(fig1, use_container_width=True)

st.header("📊 EV Penetration by Vehicle Segment (FY 2023–24)")
fig2 = px.bar(penetration_df, x="Segment", y="EV Penetration (%)", color="Segment", title="EV Penetration by Segment")
st.plotly_chart(fig2, use_container_width=True)

st.header("🏆 Top EV OEMs by Market Share (2024)")
fig3 = px.pie(oem_df, names="OEM", values="Market Share (%)", title="Top EV OEMs Market Share")
st.plotly_chart(fig3, use_container_width=True)

st.markdown("✅ Data is illustrative and compiled for academic use.")
